# Minipelit

Harjoitustyönä tehty minipelit sivu jossa<br/>
voi pelata ristinollaa kaverin kanssa online :) <br/>
Ehkä tulevaisuudessa lisään pelejä.<br/>
Frontti tehty Reactilla käyttäen mobx-tilanhallintaa.<br/>
Tiedonsiirto NodeJs (websocket) serverin välityksellä<br/>
<br/>
Front: http://minipelit.netlify.app <br/>
Backend (Nodejs): https://github.com/reeppi/ws<br/>
<br/>
Avainsanat : typescript, react, mobx, websocket, canvas, react-bootstrap<br/>
